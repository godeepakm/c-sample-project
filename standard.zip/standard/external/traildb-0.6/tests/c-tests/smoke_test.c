/* DESCRIPTION: Tests that linking and #including traildb works. */

#include <traildb.h>
#include "tdb_test.h"

int main(void)
{
    return 0;
}

