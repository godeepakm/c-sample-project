var _mbq = _mbq || [];
_mbq.push(['config', {
    domainName: '.traildb.io',
    source: 'traildb.io',
    sourceVersion: '1.0'
}]);
_mbq.push(['trackPageView']);
(function() {
    var mb = document.createElement('script'); mb.type = 'text/javascript';
    mb.src = '//app.adroll.com/j/lib/build/moneyball.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(mb, s);
})();
