$(function() {
    // Change logo link to root of the domain (landing page)
    $('.wy-side-nav-search .icon-home').attr('href', '/');
});
