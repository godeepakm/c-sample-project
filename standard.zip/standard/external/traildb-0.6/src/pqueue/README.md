
    L   oo.ooooo.   .ooooo oo oooo  oooo   .ooooo.  oooo  oooo   .ooooo.
         888' `88b d88' `888  `888  `888  d88' `88b `888  `888  d88' `88b
         888   888 888   888   888   888  888ooo888  888   888  888ooo888
    I    888   888 888   888   888   888  888    .o  888   888  888    .o
         888bod8P' `V8bod888   `V88V"V8P' `Y8bod8P'  `V88V"V8P' `Y8bod8P'
         888             888.
    B   o888o            8P'
                         "

`libpqueue` is a generic priority queue (heap) implementation used by the Apache HTTP Server project. (Particularly, 2.2.14 release.) I just tidied up the source and API a little bit, introduced some minor functionality, etc.
